<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'dress' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'AW[IGzyR3CW8Y~H!oTL6ZQXD2J@,HYRk&U50N37>Pc+T_:>=ZadSeH~lbipKbDaE' );
define( 'SECURE_AUTH_KEY',  '7P.&xt|(F(cfo#tpBDo3,J_fPDQK*$hvx<f DCf@VVye5I/yOV06@Z$D9_Dcu9zk' );
define( 'LOGGED_IN_KEY',    ']Sa=8?w`$TE^/&|gQw=9{1 ~6.ce^HqC4w},7E#VQ%pcIcoj;-3K~i92wV=C*Hgt' );
define( 'NONCE_KEY',        'cMGhEEp].Rdk@KC&^+^5R}{i)4L+v4?Uqjqae-~tsLTVNALF)6{7Hgb*;n:<xSL]' );
define( 'AUTH_SALT',        'NJt0jaPXzz3@prUk*?m[o<KHK{9Qg}@z$ 4a*4=;#W/1vWsJcK=7D@WfG+_6*387' );
define( 'SECURE_AUTH_SALT', 'oyVuun7-[RtNUT<cfWsK,]^D_t*MxArT|&l_ND{S8v@}ID ze~#]X=8%h&1#CY*f' );
define( 'LOGGED_IN_SALT',   '|!]H_a~v2$bBm<Pq]s)M:_ylAq<N^;mLvta2zfgY:jMDa%h0No YV:KWG;c,V(Ju' );
define( 'NONCE_SALT',       ',L_>$Gd4y Qcy2F1cuw98}zvK6ux{]ZdsapK-Q4Cn/vy:sEslF`$O:xp<^*e~;xx' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
